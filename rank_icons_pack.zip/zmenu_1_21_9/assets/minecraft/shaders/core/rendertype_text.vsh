#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ZArena /menu header. Title glyphs coloured (254, g, 249..253) inside the 6-row chest (176x222)
// are moved from chest-window space to screen space. Everything else renders exactly like vanilla.
void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r == 254 && c.b >= 249 && c.b <= 253 && abs(ProjMat[3][3] - 1.0) < 0.001) {
        float gw = round(2.0 / ProjMat[0][0]);
        float gh = round(-2.0 / ProjMat[1][1]);
        vec2 win = vec2(trunc((gw - 176.0) / 2.0), trunc((gh - 222.0) / 2.0));
        vec2 p = Position.xy - win;
        float lum = float(c.g) / 254.0;
        if (c.b == 253) {
            pos.xy = p;
        } else if (c.b == 252) {
            pos.xy = vec2(p.x - 88.0 + floor(gw / 2.0), p.y);
        } else if (c.b == 251) {
            pos.xy = vec2(p.x - 176.0 + gw, p.y);
        } else if (c.b == 250) {
            pos.xy = vec2(p.x * gw / 256.0, p.y);
        } else {
            pos.xy = vec2(gw - float(c.g), 8.0) + (p - vec2(0.0, 5.0)) * 3.0;
            lum = 1.0;
        }
        col = vec4(lum, lum, lum, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
