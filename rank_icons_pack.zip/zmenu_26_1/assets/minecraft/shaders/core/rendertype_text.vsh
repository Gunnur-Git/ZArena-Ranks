#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ZArena /menu, drawn on three HUD layers that the client always draws in this order:
//   boss bar name (background art)  <  action bar (content)  <  title (the fake mouse pointer).
// Their glyphs carry marker colours; this moves them onto a 480x270 canvas scaled to fit the screen
// (integer scale when it fits, anchored to the top, centred sideways).
//   boss bar red 251 / action bar red 253: blue 250 canvas | 249 pin left | 248 pin right | 247 full
//            width | 246 head; green = palette index (head: green = canvas px from the right edge)
//   pointer  red 252, blue 250/251, y = green + 256 * (blue - 250)
// Everything else renders exactly like vanilla.
const vec3 PAL[18] = vec3[](vec3(1.0000, 1.0000, 1.0000), vec3(0.9020, 0.9490, 0.9490), vec3(0.5765, 0.6902, 0.6980), vec3(0.3725, 0.4902, 0.5020), vec3(0.2510, 0.6980, 0.7176), vec3(0.3608, 0.9020, 0.3608), vec3(1.0000, 0.3333, 0.3333), vec3(1.0000, 0.8471, 0.2902), vec3(0.3333, 0.3333, 0.3333), vec3(0.1176, 0.1176, 0.1176), vec3(0.7843, 0.4588, 0.2000), vec3(0.8471, 0.8471, 0.8471), vec3(0.7059, 0.7686, 0.8157), vec3(1.0000, 0.8235, 0.2471), vec3(0.6235, 0.9020, 0.9412), vec3(0.2392, 0.8627, 0.5176), vec3(0.5569, 0.6078, 1.0000), vec3(0.8980, 0.2235, 0.2078));

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    bool layer = (c.r == 253 || c.r == 251) && c.b >= 246 && c.b <= 250;
    bool cursor = c.r == 252 && (c.b == 250 || c.b == 251);
    if ((layer || cursor) && abs(ProjMat[3][3] - 1.0) < 0.001) {
        float gw = round(2.0 / ProjMat[0][0]);
        float gh = round(-2.0 / ProjMat[1][1]);
        float fit = min(gw / 480.0, gh / 270.0);
        float s = fit >= 1.0 ? floor(fit) : fit;
        float ox = floor((gw - 480.0 * s) / 2.0);
        if (layer) {
            vec2 v = c.r == 253
                ? Position.xy - vec2(floor(gw / 2.0), gh - 68.0) + vec2(8.0, 10.0)     // action bar
                : Position.xy - vec2(floor(gw / 2.0), 0.0) + vec2(8.0, 3.0);           // boss bar name
            if (c.b == 250) {
                pos.xy = vec2(ox, 0.0) + v * s;
            } else if (c.b == 249) {
                pos.xy = v * s;
            } else if (c.b == 248) {
                pos.xy = vec2(gw - (480.0 - v.x) * s, v.y * s);
            } else if (c.b == 247) {
                pos.xy = vec2(v.x * gw / 256.0, v.y * s);
            } else {
                pos.xy = vec2(gw - float(c.g) * s, 8.0 * s) + (v - vec2(0.0, 5.0)) * 3.0 * s;
            }
            col = vec4(c.b == 246 ? vec3(1.0) : PAL[min(c.g, 18 - 1)], Color.a);
        } else {
            vec2 v = (Position.xy - vec2(floor(gw / 2.0), floor(gh / 2.0))) / 4.0 + vec2(8.0, 16.0);   // title, 4x
            float cy = float(c.g) + 256.0 * float(c.b - 250);
            pos.xy = vec2(ox + v.x * s, (cy + v.y - 6.0) * s);
            col = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
